print('''White-capped rocky cliffs and steppes
Are equal to the soul of our people.
For countless centuries, our fathers
Have lived in and kept the Ala-Too.

March forward, Kyrgyz people,
On the way to freedom!
Prosperity and progress,
Your own fate is in your hands!''')
