#print ('''A "quoted" String is",\n,"'much' better if you learn",\n,"the rules of "escape sequences."",\n,"Also, "" represents an empty String.""",\n,"Don't forget: use '\'" instead of " !
#",\n"'' is not the same as "''')
#daha eksik düzeltilecek bu sadece copy paste için
def method1():
    print ('A "quoted" String is')
    print ("'much' better if you learn")
    print ('the rules of "escape sequences."')
    print ('Also, "" represents an empty String.')
    print ('don\'t forget: use " instead of " !')
    print ('" is not the same as"')
method1()